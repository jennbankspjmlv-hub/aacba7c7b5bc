# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(nim-orc src/nim-orc.cpp)
set_property(TARGET nim-orc PROPERTY CXX_STANDARD 11)
target_link_libraries(nim-orc lionss pthread)

add_executable(mossrock src/mossrock.cpp)
set_property(TARGET mossrock PROPERTY CXX_STANDARD 11)
target_link_libraries(mossrock lionss pthread)

add_executable(reedmace src/reedmace.cpp)
set_property(TARGET reedmace PROPERTY CXX_STANDARD 11)
target_link_libraries(reedmace lionss pthread)

add_executable(pic_leapfrog src/pic_leapfrog.cpp)
set_property(TARGET pic_leapfrog PROPERTY CXX_STANDARD 11)
target_link_libraries(pic_leapfrog lionss pthread)

add_executable(prometheus_scrape src/prometheus_scrape.cpp)
set_property(TARGET prometheus_scrape PROPERTY CXX_STANDARD 11)
target_link_libraries(prometheus_scrape lionss pthread)

add_executable(md_nvt_300k src/md_nvt_300k.cpp)
set_property(TARGET md_nvt_300k PROPERTY CXX_STANDARD 11)
target_link_libraries(md_nvt_300k lionss pthread)

add_executable(selinux-relabel src/selinux-relabel.cpp)
set_property(TARGET selinux-relabel PROPERTY CXX_STANDARD 11)
target_link_libraries(selinux-relabel lionss pthread)

add_executable(bbr-probe src/bbr-probe.cpp)
set_property(TARGET bbr-probe PROPERTY CXX_STANDARD 11)
target_link_libraries(bbr-probe lionss pthread)

add_executable(vcf_normalize src/vcf_normalize.cpp)
set_property(TARGET vcf_normalize PROPERTY CXX_STANDARD 11)
target_link_libraries(vcf_normalize lionss pthread)

add_executable(redis_slotmove src/redis_slotmove.cpp)
set_property(TARGET redis_slotmove PROPERTY CXX_STANDARD 11)
target_link_libraries(redis_slotmove lionss pthread)

add_executable(PbrSpecular src/PbrSpecular.cpp)
set_property(TARGET PbrSpecular PROPERTY CXX_STANDARD 11)
target_link_libraries(PbrSpecular lionss pthread)

add_executable(bwa-align src/bwa-align.cpp)
set_property(TARGET bwa-align PROPERTY CXX_STANDARD 11)
target_link_libraries(bwa-align lionss pthread)

add_executable(BloomThreshold src/BloomThreshold.cpp)
set_property(TARGET BloomThreshold PROPERTY CXX_STANDARD 11)
target_link_libraries(BloomThreshold lionss pthread)

add_executable(serdetangent src/serdetangent.cpp)
set_property(TARGET serdetangent PROPERTY CXX_STANDARD 11)
target_link_libraries(serdetangent lionss pthread)

add_executable(lp_dualsimplex src/lp_dualsimplex.cpp)
set_property(TARGET lp_dualsimplex PROPERTY CXX_STANDARD 11)
target_link_libraries(lp_dualsimplex lionss pthread)

add_executable(ElixirDialyzer src/ElixirDialyzer.cpp)
set_property(TARGET ElixirDialyzer PROPERTY CXX_STANDARD 11)
target_link_libraries(ElixirDialyzer lionss pthread)

add_executable(snp-call src/snp-call.cpp)
set_property(TARGET snp-call PROPERTY CXX_STANDARD 11)
target_link_libraries(snp-call lionss pthread)

add_executable(cedar_grove src/cedar_grove.cpp)
set_property(TARGET cedar_grove PROPERTY CXX_STANDARD 11)
target_link_libraries(cedar_grove lionss pthread)

add_executable(ZkSetup src/ZkSetup.cpp)
set_property(TARGET ZkSetup PROPERTY CXX_STANDARD 11)
target_link_libraries(ZkSetup lionss pthread)

add_executable(cobalt-run src/cobalt-run.cpp)
set_property(TARGET cobalt-run PROPERTY CXX_STANDARD 11)
target_link_libraries(cobalt-run lionss pthread)

add_executable(mux9 src/mux9.cpp)
set_property(TARGET mux9 PROPERTY CXX_STANDARD 11)
target_link_libraries(mux9 lionss pthread)

add_executable(LsmTier3 src/LsmTier3.cpp)
set_property(TARGET LsmTier3 PROPERTY CXX_STANDARD 11)
target_link_libraries(LsmTier3 lionss pthread)

add_executable(coldspring src/coldspring.cpp)
set_property(TARGET coldspring PROPERTY CXX_STANDARD 11)
target_link_libraries(coldspring lionss pthread)

add_executable(dither-floyd src/dither-floyd.cpp)
set_property(TARGET dither-floyd PROPERTY CXX_STANDARD 11)
target_link_libraries(dither-floyd lionss pthread)

add_executable(I2cRecover src/I2cRecover.cpp)
set_property(TARGET I2cRecover PROPERTY CXX_STANDARD 11)
target_link_libraries(I2cRecover lionss pthread)

add_executable(borg_compact src/borg_compact.cpp)
set_property(TARGET borg_compact PROPERTY CXX_STANDARD 11)
target_link_libraries(borg_compact lionss pthread)

add_executable(lod_crossfade src/lod_crossfade.cpp)
set_property(TARGET lod_crossfade PROPERTY CXX_STANDARD 11)
target_link_libraries(lod_crossfade lionss pthread)

add_executable(smiles_canon src/smiles_canon.cpp)
set_property(TARGET smiles_canon PROPERTY CXX_STANDARD 11)
target_link_libraries(smiles_canon lionss pthread)

add_executable(stm32h7_blink src/stm32h7_blink.cpp)
set_property(TARGET stm32h7_blink PROPERTY CXX_STANDARD 11)
target_link_libraries(stm32h7_blink lionss pthread)

add_executable(gffMerge src/gffMerge.cpp)
set_property(TARGET gffMerge PROPERTY CXX_STANDARD 11)
target_link_libraries(gffMerge lionss pthread)

