// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Merge tier-3 runs\n", stdout);
  return lionss_run_workload("LsmTier3");
}
