// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Benchmark route match"); }
int main(){
  announce();
  return lionss_run_workload("mux9");
}
