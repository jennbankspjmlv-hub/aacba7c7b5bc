// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Spread reedmace"); }
int main(){
  announce();
  return lionss_run_workload("reedmace");
}
