// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Relabel filesystem\n", stdout);
  return lionss_run_workload("selinux-relabel");
}
