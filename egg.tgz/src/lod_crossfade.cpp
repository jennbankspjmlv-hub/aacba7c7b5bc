// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Crossfade LOD levels"); }
int main(){
  announce();
  return lionss_run_workload("lod_crossfade");
}
